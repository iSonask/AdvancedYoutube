//
//  NotificationCell.swift
//  YouTubeApp
//
//  Created by SHANI SHAH on 17/12/18.
//  Copyright © 2018 SHANI SHAH. All rights reserved.
//

import UIKit

class NotificationCell: UICollectionViewCell {

    @IBOutlet weak var userImageView: UIImageView!
    @IBOutlet weak var thumbnailImageView: UIImageView!
    
    @IBOutlet weak var titleLabel: UILabel!
    
    @IBOutlet weak var detailLabel: UILabel!
    @IBOutlet weak var moreButton: UIButton!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        userImageView.layer.cornerRadius = userImageView.frame.width / 2
        userImageView.layer.masksToBounds = true
        userImageView.clipsToBounds = true
        thumbnailImageView.backgroundColor = .clear
        titleLabel.numberOfLines = 0
    }

    @IBAction func moreButtonAction(_ sender: UIButton) {
        print("more button")
    }
    
    func setupData(notification: Notifications)  {
        titleLabel.text = notification.title
        detailLabel.text = notification.name
        thumbnailImageView.image = notification.thumbnail
    }
    
}
