//
//  InboxCell.swift
//  YouTubeApp
//
//  Created by SHANI SHAH on 17/12/18.
//  Copyright © 2018 SHANI SHAH. All rights reserved.
//

import UIKit

class InboxCell: UICollectionViewCell {
    
    
    @IBOutlet weak var inboxCollectionView: UICollectionView!
    
    var index = 0
    
    var messages = [Messages]()
    var notifications = [Notifications]()
    
    override func awakeFromNib() {
        super.awakeFromNib()
        messages = [Messages(name: "starkExpo", title: "iron man Video HD"),Messages(name: "starkExpo", title: "iron man Video HD"),Messages(name: "starkExpo", title: "iron man Video HD"),Messages(name: "starkExpo", title: "iron man Video HD"),Messages(name: "starkExpo", title: "iron man Video HD"),Messages(name: "starkExpo", title: "iron man Video HD"),Messages(name: "starkExpo", title: "iron man Video HD"),Messages(name: "starkExpo", title: "iron man Video HD"),Messages(name: "starkExpo", title: "iron man Video HD"),Messages(name: "starkExpo", title: "iron man Video HD"),Messages(name: "starkExpo", title: "iron man Video HD"),Messages(name: "starkExpo", title: "iron man Video HD"),Messages(name: "starkExpo", title: "iron man Video HD"),Messages(name: "starkExpo", title: "iron man Video HD"),Messages(name: "starkExpo", title: "iron man Video HD")]
        
        notifications = [Notifications(name: "infinitywar", title: "Avenger Infinity war part 4 Release date confirm HD video globally share globally share thanks for watching globally share thanks for watching", thumbnail: UIImage(named: "logoBlack")),Notifications(name: "infinitywar", title: "Avenger Infinity war part 4 Release date confirm HD video globally share", thumbnail: UIImage(named: "logoBlack")),Notifications(name: "infinitywar", title: "Avengerglobally share thanks for watchingglobally share thanks for watchingglobally share thanks for watching Infinity war part 4 Release date confirm HD video globally share", thumbnail: UIImage(named: "logoBlack")),Notifications(name: "infinitywar", title: "Avenger Infinity war part 4 Release date confirm HD video globally share", thumbnail: UIImage(named: "logoBlack")),Notifications(name: "infinitywar", title: "Avenger Infinity war part 4 Release date confirm HD video globally share", thumbnail: UIImage(named: "logoBlack")),Notifications(name: "infinitywar", title: "Avenger Infinity war part 4 Release date confirm HD video globally share", thumbnail: UIImage(named: "logoBlack")),Notifications(name: "infinitywar", title: "Avenger Infinity war part 4 Release date globally share thanks for watchingglobally share thanks for watchingconfirm HD video globally share", thumbnail: UIImage(named: "logoBlack")),Notifications(name: "infinitywar", title: "Avenger Infinity war part 4 Release date confirm HD video globally share", thumbnail: UIImage(named: "logoBlack")),Notifications(name: "infinitywar", title: "Avenger Infinity war part 4 Release date confirm HD video globally share thanks for watching", thumbnail: UIImage(named: "logoBlack")),Notifications(name: "infinitywar", title: "Avenger Infinity war part 4 Release date confirm HD video globglobally share thanks for watchingglobally share thanks for watchingally share", thumbnail: UIImage(named: "logoBlack")),Notifications(name: "infinitywar", title: "Avenger Infiglobally share thanks for watchingglobally share thanks for watchingnity war part 4 Release date confirm HD video globally share", thumbnail: UIImage(named: "logoBlack")),Notifications(name: "infinitywar", title: "Avenger Infinity war part 4 Release date confirm HD video globally share", thumbnail: UIImage(named: "logoBlack")),Notifications(name: "infinitywar", title: "Avenger Infinity war part 4 Release date confirm HD video globally share", thumbnail: UIImage(named: "logoBlack")),Notifications(name: "infinitywar", title: "Avenger Infinity war part 4 Release date confirm HD video globally share", thumbnail: UIImage(named: "logoBlack")),Notifications(name: "infinitywar", title: "Avengeglobally share thanks for watchingglobally share thanks for watchingglobally share thanks for watchingglobally share thanks for watchingglobally share thanks for watchingglobally share thanks for watchingglobally share thanks for watchingr Infinity war part 4 Release date confirm HD video globally share", thumbnail: UIImage(named: "logoBlack"))]
    }
    
    func setupData(index: Int)  {
        
        self.index = index
        inboxCollectionView.delegate = self
        inboxCollectionView.dataSource = self

    }
    
}

extension InboxCell: UICollectionViewDelegate{
    
}

extension InboxCell: UICollectionViewDataSource{
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if index == 0{
            return messages.count
        } else {
            return notifications.count
        }
//        3Xv1mJvwXok
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if index == 0{
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "MessageCell", for: indexPath) as! MessageCell
            cell.setupData(message: messages[indexPath.row])
            return cell
        } else {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "NotificationCell", for: indexPath) as! NotificationCell
            cell.setupData(notification: notifications[indexPath.row])
            return cell
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let controller = storyboard.instantiateViewController(withIdentifier: "DetailController") as! DetailController
        let window = (UIApplication.shared.delegate as! AppDelegate).window
        window?.rootViewController!.present(controller, animated: true, completion: nil)
    }
    
}

extension InboxCell: UICollectionViewDelegateFlowLayout{
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        if index == 0{
            return CGSize(width: inboxCollectionView.frame.width, height: 60)
        } else {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "NotificationCell", for: indexPath) as! NotificationCell
            let approximateWidthOfContent = cell.titleLabel.frame.width
            // x is the width of the logo in the left
            
            let size = CGSize(width: approximateWidthOfContent, height: 1000)
            
            //1000 is the large arbitrary values which should be taken in case of very high amount of content
            
            let attributes = [NSAttributedString.Key.font: UIFont.systemFont(ofSize: 13)]
            let estimatedFrame = NSString(string: notifications[indexPath.row].title).boundingRect(with: size, options: .usesLineFragmentOrigin, attributes: attributes, context: nil)
            return CGSize(width: collectionView.frame.width, height: estimatedFrame.height + 80)

        }
    }
    
}

struct Messages {
    let name: String!
    let title: String!
}

struct Notifications {
    
    let name: String!
    let title: String!
    let thumbnail: UIImage!
}
