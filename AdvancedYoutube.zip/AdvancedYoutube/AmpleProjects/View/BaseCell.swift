//
//  BaseCell.swift
//  YouTubeApp
//
//  Created by SHANI SHAH on 17/12/18.
//  Copyright © 2018 SHANI SHAH. All rights reserved.
//

import UIKit

class BaseCell: UICollectionViewCell {
    
    @IBOutlet weak var thumbnailImageView: UIImageView!
    
    @IBOutlet weak var timeLabel: UILabel!
    @IBOutlet weak var userImageView: UIImageView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var descriptionLabel: UILabel!
    
    @IBOutlet weak var moreButton: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        setupUI()
        setupData()
    }
    
    func setupUI()  {
        userImageView.layer.cornerRadius = userImageView.frame.width / 2
        userImageView.layer.masksToBounds = true
        userImageView.clipsToBounds = true
        
        titleLabel.numberOfLines = 2
        
        timeLabel.backgroundColor = .black
        timeLabel.textColor = .white
        timeLabel.font = UIFont.systemFont(ofSize: 12)
        timeLabel.textAlignment = .center
        
        titleLabel.font = UIFont.systemFont(ofSize: 14)
        descriptionLabel.font = UIFont.systemFont(ofSize: 12)
        descriptionLabel.textColor = .gray
    }
    
    func setupData() {
        timeLabel.text = "00:00"
        userImageView.image = UIImage(named: "iconUser")
        titleLabel.text = "iron man - tony stark"
        descriptionLabel.text = "StarkExpo ~ 348K views ~ 3 months ago"
    }
    
    @IBAction func moreButtonAction(_ sender: UIButton) {
        
    }
    
}
