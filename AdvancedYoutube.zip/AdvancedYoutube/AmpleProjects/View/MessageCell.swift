//
//  MessageCell.swift
//  YouTubeApp
//
//  Created by SHANI SHAH on 17/12/18.
//  Copyright © 2018 SHANI SHAH. All rights reserved.
//

import UIKit

class MessageCell: UICollectionViewCell {

    @IBOutlet weak var userImageView: UIImageView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var detailLabel: UILabel!
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        userImageView.layer.cornerRadius = userImageView.frame.width / 2
        userImageView.layer.masksToBounds = true
        userImageView.clipsToBounds = true
        
        titleLabel.numberOfLines = 2
        
    }
    
    func setupData(message: Messages)  {
        titleLabel.text = message.title
        detailLabel.text = message.name
    }
    
}
