//
//  LibraryController.swift
//  YouTubeApp
//
//  Created by SHANI SHAH on 17/12/18.
//  Copyright © 2018 SHANI SHAH. All rights reserved.
//

import UIKit

class LibraryController: BaseController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print("Library")
        // Do any additional setup after loading the view.
    }
    
}
