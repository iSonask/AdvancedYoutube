//
//  ViewController.swift
//  YouTubeApp
//
//  Created by SHANI SHAH on 17/12/18.
//  Copyright © 2018 SHANI SHAH. All rights reserved.
//

import UIKit
import AVFoundation

class TabBarController: UITabBarController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
    
        tabBar.tintColor = .black
        for i in 0...self.tabBar.items!.count {
            print(i)
            if i == 0{
                self.tabBar.items![i].title = "Home"
                self.tabBar.items![i].image = UIImage(named: "iconHome")
            } else if i == 1{
                self.tabBar.items![i].title = "Trending"
                self.tabBar.items![i].image = UIImage(named: "iconTrending")
            }else if i == 2{
                self.tabBar.items![i].title = "Subscriptions"
                self.tabBar.items![i].image = UIImage(named: "iconSubscription")
            }else if i == 3{
                self.tabBar.items![i].title = "Inbox"
                self.tabBar.items![i].image = UIImage(named: "iconInbox")
            }else if i == 4{
                self.tabBar.items![i].title = "Library"
                self.tabBar.items![i].image = UIImage(named: "iconLibrary")
            } else {}
        }
    
    }
}

class BaseController: UIViewController {
    
    var navView = CustomTitleView()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupNavigation()
//        navigationController!.hidesBarsOnSwipe = true
    }
    
    func setupNavigation() {
        
        
        navView.loadWith(title: "YouTube", leftImage: UIImage(named: "logoBlack"))
        
        
        // Set the navigation bar's navigation item's titleView to the navView
        let leftView = UIBarButtonItem(customView: navView)
        
        navigationItem.leftBarButtonItem = leftView
        
        // Set the navView's frame to fit within the titleView
        navView.sizeToFit()

        navigationController!.navigationBar.tintColor = .black
        
        let airplayButton = UIBarButtonItem(image: UIImage(named: "iconAirPlay")?.maskWithColor(color: .black), style: .plain, target: self, action: #selector(handleAirPlay))
//        airplayButton.imageInsets = UIEdgeInsets(top: 0, left: 50, bottom: 0, right: 0)
        let videoButton = UIBarButtonItem(image: UIImage(named: "iconVideo")?.maskWithColor(color: .black), style: .plain, target: self, action: #selector(handleVideo))
//        videoButton.imageInsets = UIEdgeInsets(top: 0, left: 40, bottom: 0, right: 0)
        let searchButton = UIBarButtonItem(image: UIImage(named: "iconSearch")?.maskWithColor(color: .black), style: .plain, target: self, action: #selector(handleSearch))
//        searchButton.imageInsets = UIEdgeInsets(top: 0, left: 30, bottom: 0, right: 0)
        let userButton = UIBarButtonItem(image: UIImage(named: "iconUser")?.maskWithColor(color: .black), style: .plain, target: self, action: #selector(handleUser))
        navigationItem.rightBarButtonItems = [userButton,searchButton,videoButton,airplayButton]
        
    }
    
    @objc func handleAirPlay(){
        
    }
    
    @objc func handleVideo(){
        
    }
    
    @objc func handleSearch(){
        
    }
    
    @objc func handleUser(){
        let controller = storyboard?.instantiateViewController(withIdentifier: "AccountController") as! AccountController
        present(controller, animated: true, completion: nil)
    }
    
    
    func generateThumbnailImageWithDuration(imageURl: String) -> (UIImage, String) {
        
        do {
            let asset = AVURLAsset(url: URL(string: imageURl)! , options: nil)
            let imgGenerator = AVAssetImageGenerator(asset: asset)
            imgGenerator.appliesPreferredTrackTransform = true
            let cgImage = try! imgGenerator.copyCGImage(at: CMTimeMake(value: 0, timescale: 1), actualTime: nil)
            let image = UIImage(cgImage: cgImage)
            let duration = AVURLAsset(url: URL(string: imageURl)!).duration.seconds
            let time: String
            if duration > 3600 {
                time = String(format:"%d:%d:%d",
                              Int(duration/3600),
                              Int((duration/60).truncatingRemainder(dividingBy: 60)),
                              Int(duration.truncatingRemainder(dividingBy: 60)))
            } else {
                time = String(format:"%d:%d",
                              Int((duration/60).truncatingRemainder(dividingBy: 60)),
                              Int(duration.truncatingRemainder(dividingBy: 60)))
            }
            print("success")
            return(image,time)
        } 
    }
    
}

extension BaseController: UIScrollViewDelegate{
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let pan = scrollView.panGestureRecognizer
        let velocity = pan.velocity(in: scrollView).y
        if velocity < -5 {
//            self.navigationController?.setNavigationBarHidden(true, animated: true)
        } else if velocity > 5 {
//            self.navigationController?.setNavigationBarHidden(false, animated: true)
        }
    }
}


extension UIImage {
    
    func maskWithColor(color: UIColor) -> UIImage? {
        let maskImage = cgImage!
        
        let width = size.width
        let height = size.height
        let bounds = CGRect(x: 0, y: 0, width: width, height: height)
        
        let colorSpace = CGColorSpaceCreateDeviceRGB()
        let bitmapInfo = CGBitmapInfo(rawValue: CGImageAlphaInfo.premultipliedLast.rawValue)
        let context = CGContext(data: nil, width: Int(width), height: Int(height), bitsPerComponent: 8, bytesPerRow: 0, space: colorSpace, bitmapInfo: bitmapInfo.rawValue)!
        
        context.clip(to: bounds, mask: maskImage)
        context.setFillColor(color.cgColor)
        context.fill(bounds)
        
        if let cgImage = context.makeImage() {
            let coloredImage = UIImage(cgImage: cgImage)
            return coloredImage
        } else {
            return nil
        }
    }
}

class CustomTitleView: UIView{
    
    var titlelabel = UILabel()
    var leftimageView = UIImageView()
    
    override init(frame: CGRect){
        super.init(frame: frame)
        setup()
    }
    
    required init?(coder aDecoder: NSCoder){
        super.init(coder: aDecoder)
        setup()
    }
    
    func setup(){
        self.addSubview(titlelabel)
        self.addSubview(leftimageView)
        
    }
    
    func loadWith(title: String, leftImage: UIImage?){
        
        //self.backgroundColor = .yellow
        
        // =================== title_label ==================
        //title_label.backgroundColor = .blue
        titlelabel.text = title
        titlelabel.font = UIFont.boldSystemFont(ofSize: 14)
        
        
        // =================== imageView ===================
        leftimageView.image = leftImage
        
        setupFrames()
    }
    
    func setupFrames(){
        
        let height: CGFloat = 45
        let image_size: CGFloat = height * 0.8
        
        leftimageView.frame = CGRect(x: 0,
                                     y: (height - image_size) / 2,
                                     width: (leftimageView.image == nil) ? 0 : image_size,
                                     height: image_size)
        
        let titleWidth: CGFloat = titlelabel.intrinsicContentSize.width + 10
        titlelabel.frame = CGRect(x: leftimageView.frame.maxX + 5,
                                  y: 0,
                                  width: titleWidth,
                                  height: height)
        
        
        
        contentWidth = Int(leftimageView.frame.width)
        self.frame = CGRect(x: 0, y: 0, width: CGFloat(contentWidth), height: height)
    }
    
    var contentWidth: Int = 0 //if its CGFloat, it infinitely calls layoutSubviews(), changing franction of a width
    override func layoutSubviews() {
        super.layoutSubviews()
        
        self.frame.size.width = CGFloat(contentWidth)
        
    }
    
}
