//
//  DetailController.swift
//  YouTubeApp
//
//  Created by SHANI SHAH on 18/12/18.
//  Copyright © 2018 SHANI SHAH. All rights reserved.
//

import UIKit

class DetailController: UIViewController {

    @IBOutlet weak var playerView: UIView!
//3Xv1mJvwXok
    private var player: YTSwiftyPlayer!

    @IBOutlet weak var closeButton: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        
//        closeButton.setImage(UIImage(named: "iconClose")?.maskWithColor(color: .white), for: .normal)
//        player.delegate = self
//        player.playVideo("https://sample-videos.com/video123/mp4/480/big_buck_bunny_480p_1mb.mp4")
        // Create a new player
        
        player = YTSwiftyPlayer(frame: playerView.bounds, playerVars: [.playsInline(true), .videoID("3Xv1mJvwXok"), .loopVideo(true), .showRelatedVideo(false)])
        player.frame = playerView.bounds
//        player.loadVideo(videoID: "v=3Xv1mJvwXok")
        // Enable auto playback when video is loaded
//        player.autoplay = true
        
        // Set player view
        player.playVideo()
        // Set delegate for detect callback information from the player
        player.delegate = self
        
        // Load video player
        player.loadPlayer()
        
    }

//    func callBackDownloadDidFinish(_ status: playerItemStatus?) {
//
//        let status:playerItemStatus = status!
//        switch status {
//        case .readyToPlay:
//            player.startPlayback()
//            break
//        case .failed:
//            break
//        default:
//            break
//        }
//    }
    @IBAction func closeButtonAction(_ sender: UIButton) {
        dismiss(animated: true, completion: nil)
    }
    
}

extension DetailController: YTSwiftyPlayerDelegate {
    
    func playerReady(_ player: YTSwiftyPlayer) {
        print(#function)
        // After loading a video, player's API is available.
        // e.g. player.mute()
    }
    
    func player(_ player: YTSwiftyPlayer, didUpdateCurrentTime currentTime: Double) {
        print("\(#function):\(currentTime)")
    }
    
    func player(_ player: YTSwiftyPlayer, didChangeState state: YTSwiftyPlayerState) {
        print("\(#function):\(state)")
    }
    
    func player(_ player: YTSwiftyPlayer, didChangePlaybackRate playbackRate: Double) {
        print("\(#function):\(playbackRate)")
    }
    
    func player(_ player: YTSwiftyPlayer, didReceiveError error: YTSwiftyPlayerError) {
        print("\(#function):\(error)")
    }
    
    func player(_ player: YTSwiftyPlayer, didChangeQuality quality: YTSwiftyVideoQuality) {
        print("\(#function):\(quality)")
    }
    
    func apiDidChange(_ player: YTSwiftyPlayer) {
        print(#function)
    }
    
    func youtubeIframeAPIReady(_ player: YTSwiftyPlayer) {
        print(#function)
    }
    
    func youtubeIframeAPIFailedToLoad(_ player: YTSwiftyPlayer) {
        print(#function)
    }
}
