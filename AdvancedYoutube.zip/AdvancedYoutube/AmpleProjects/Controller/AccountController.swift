//
//  AccountController.swift
//  YouTubeApp
//
//  Created by SHANI SHAH on 17/12/18.
//  Copyright © 2018 SHANI SHAH. All rights reserved.
//  

import UIKit

class AccountController: UIViewController {

    @IBOutlet weak var accountTableView: UITableView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var userImageView: UIImageView!
    @IBOutlet weak var dismissButton: UIButton!
    
    var accounts = ["My channel","Time watched","Paid memberships","Switch account","Settings","Terms & privacy policy","Help & feedback"]
    
    var accountImages = [UIImage(named: "iconUser"),UIImage(named: "iconTimeWatched"),UIImage(named: "iconPaidMember"),UIImage(named: "iconChannel"),UIImage(named: "iconSetting"),UIImage(named: "iconTerms")?.maskWithColor(color: .black),UIImage(named: "iconHelps")]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
        nameLabel.text = "Tony Stark"
        titleLabel.text = "Account"
    }
    
    func setup()  {
        accountTableView.tableFooterView = UIView()
        accountTableView.backgroundColor = UIColor(red: 245.0/255.0, green: 245.0/255.0, blue: 245.0/255.0, alpha: 1.0)
        accountTableView.contentOffset = .zero
        
        userImageView.contentMode = .scaleAspectFit
        userImageView.image = UIImage(named: "iconUser")
        dismissButton.setImage(UIImage(named: "iconClose"), for: .normal)
        dismissButton.imageView?.contentMode = .scaleAspectFit
        
    }
    
    @IBAction func handleDismissAction(_ sender: UIButton){
        dismiss(animated: true, completion: nil)
    }
    
}
extension AccountController: UITableViewDelegate{
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 55
    }
    
}
extension AccountController: UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return accounts.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "AccountCell", for: indexPath) as! AccountCell
        if indexPath.row == 3{
            tableView.separatorStyle = .singleLine
        } else {
            tableView.separatorStyle = .none
        }
        cell.accountImageView.image =  accountImages[indexPath.row]
        cell.nameLabel.text = accounts[indexPath.row]
        return cell
    }
}
