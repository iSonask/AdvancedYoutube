//
//  InboxController.swift
//  YouTubeApp
//
//  Created by SHANI SHAH on 17/12/18.
//  Copyright © 2018 SHANI SHAH. All rights reserved.
//

import UIKit

class InboxController: BaseController {
    
    @IBOutlet weak var inboxCollectionView: UICollectionView!
    
    
    @IBOutlet weak var messageButton: UIButton!
    @IBOutlet weak var notificationButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print("Inbox")
        // Do any additional setup after loading the view.
        inboxCollectionView?.isPagingEnabled = true

    }
    
    @IBAction func notificationButtonAction(_ sender: UIButton) {
        let index = IndexPath(item: 1, section: 0)
        inboxCollectionView.scrollToItem(at: index, at: .right, animated: true)
        sender.backgroundColor = .white
        sender.superview?.backgroundColor = .black
        messageButton.backgroundColor = .white
        messageButton.superview?.backgroundColor = .white
    }
    
    @IBAction func messageButtonAction(_ sender: UIButton) {
        let index = IndexPath(item: 0, section: 0)
        inboxCollectionView.scrollToItem(at: index, at: .right, animated: true)
        sender.backgroundColor = .white
        sender.superview?.backgroundColor = .black
        notificationButton.backgroundColor = .white
        notificationButton.superview?.backgroundColor = .white
    }
    
    func scrollViewWillEndDragging(_ scrollView: UIScrollView, withVelocity velocity: CGPoint, targetContentOffset: UnsafeMutablePointer<CGPoint>) {
        inboxCollectionView.contentOffset = scrollView.contentOffset
        let pageWidth:Float = Float(inboxCollectionView.bounds.width)
        
        let cellToSwipe:Double = Double(Float((scrollView.contentOffset.x))/Float((pageWidth)))
        let indexPath:IndexPath = IndexPath(row: Int(cellToSwipe), section:0)
        inboxCollectionView.scrollToItem(at:indexPath, at: UICollectionView.ScrollPosition.left, animated: true)
    }

}

extension InboxController: UICollectionViewDelegateFlowLayout{
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: collectionView.frame.width, height: collectionView.frame.height)
    }
    
}

extension InboxController: UICollectionViewDelegate{
    
}

extension InboxController: UICollectionViewDataSource{
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 2
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "InboxCell", for: indexPath) as! InboxCell
        cell.setupData(index: indexPath.row)
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        if indexPath.item == 0{
            messageButton.backgroundColor = .white
            messageButton.superview?.backgroundColor = .black
            notificationButton.backgroundColor = .white
            notificationButton.superview?.backgroundColor = .white
        } else {
            messageButton.backgroundColor = .white
            messageButton.superview?.backgroundColor = .white
            notificationButton.backgroundColor = .white
            notificationButton.superview?.backgroundColor = .black
        }
    }
    
}


