//
//  TrendingController.swift
//  YouTubeApp
//
//  Created by SHANI SHAH on 17/12/18.
//  Copyright © 2018 SHANI SHAH. All rights reserved.
//

import UIKit

class TrendingController: BaseController {

    @IBOutlet weak var trendingCollectionView: UICollectionView!
    var refresh:UIRefreshControl!
    var thumbnailImageView = UIImage()
    var timeString = ""

    override func viewDidLoad() {
        super.viewDidLoad()
        print("Trending")
        // Do any additional setup after loading the view.
        refresh = UIRefreshControl()
        refresh.tintColor = .black
        refresh.addTarget(self, action: #selector(loadData), for: .valueChanged)
        trendingCollectionView!.addSubview(refresh)
        
        let thumbData = generateThumbnailImageWithDuration(imageURl:  "https://sample-videos.com/video123/mp4/480/big_buck_bunny_480p_1mb.mp4")
        
        thumbnailImageView = thumbData.0
        timeString = thumbData.1
    }
    
    @objc func loadData() {
        DispatchQueue.main.asyncAfter(deadline: DispatchTime(uptimeNanoseconds: UInt64(3))) {
            self.stopRefresher()
        }
        
    }
    
    func stopRefresher() {
        self.refresh.endRefreshing()
    }
    
}

extension TrendingController: UICollectionViewDelegate{
    
}

extension TrendingController: UICollectionViewDataSource{
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 10
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "BaseCell", for: indexPath) as! BaseCell
        cell.thumbnailImageView.image = thumbnailImageView
        cell.timeLabel.text = timeString
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let controller = storyboard?.instantiateViewController(withIdentifier: "DetailController") as! DetailController
        present(controller, animated: true, completion: nil)
    }
}
extension TrendingController: UICollectionViewDelegateFlowLayout{
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: collectionView.frame.width , height: (collectionView.frame.height / 2) - 0)
    }
    
}
